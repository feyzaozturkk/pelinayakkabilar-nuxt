<template>
  <UyeGiris/>
</template>
<script>

  import UyeGiris from "../../components/default/UyeGiris";
  export default {
    name: "login",
    components: {UyeGiris},
  }
</script>

<style scoped>

</style>
