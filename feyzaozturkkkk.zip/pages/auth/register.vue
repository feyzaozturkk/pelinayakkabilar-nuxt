<template>
  <uyelik/>
</template>

<script>
  import Uyelik from "../../components/default/Uyelik";

  export default {
    name: "register",
    components: {Uyelik}
  }
</script>

<style scoped>

</style>
