export { default as Logo } from '../..\\components\\Logo.vue'
export { default as VuetifyLogo } from '../..\\components\\VuetifyLogo.vue'
export { default as Arama } from '../..\\components\\default\\Arama.vue'
export { default as Ayakkabilar } from '../..\\components\\default\\Ayakkabilar.vue'
export { default as Ayakkabiturleri } from '../..\\components\\default\\Ayakkabiturleri.vue'
export { default as Foto } from '../..\\components\\default\\Foto.vue'
export { default as HelloWorld } from '../..\\components\\default\\HelloWorld.vue'
export { default as Kategoriler } from '../..\\components\\default\\Kategoriler.vue'
export { default as Secenekler } from '../..\\components\\default\\Secenekler.vue'
export { default as Sepet } from '../..\\components\\default\\Sepet.vue'
export { default as Siparis } from '../..\\components\\default\\Siparis.vue'
export { default as UyeGiris } from '../..\\components\\default\\UyeGiris.vue'
export { default as Uyelik } from '../..\\components\\default\\Uyelik.vue'

export const LazyLogo = import('../..\\components\\Logo.vue' /* webpackChunkName: "components_Logo" */).then(c => c.default || c)
export const LazyVuetifyLogo = import('../..\\components\\VuetifyLogo.vue' /* webpackChunkName: "components_VuetifyLogo" */).then(c => c.default || c)
export const LazyArama = import('../..\\components\\default\\Arama.vue' /* webpackChunkName: "components_default/Arama" */).then(c => c.default || c)
export const LazyAyakkabilar = import('../..\\components\\default\\Ayakkabilar.vue' /* webpackChunkName: "components_default/Ayakkabilar" */).then(c => c.default || c)
export const LazyAyakkabiturleri = import('../..\\components\\default\\Ayakkabiturleri.vue' /* webpackChunkName: "components_default/Ayakkabiturleri" */).then(c => c.default || c)
export const LazyFoto = import('../..\\components\\default\\Foto.vue' /* webpackChunkName: "components_default/Foto" */).then(c => c.default || c)
export const LazyHelloWorld = import('../..\\components\\default\\HelloWorld.vue' /* webpackChunkName: "components_default/HelloWorld" */).then(c => c.default || c)
export const LazyKategoriler = import('../..\\components\\default\\Kategoriler.vue' /* webpackChunkName: "components_default/Kategoriler" */).then(c => c.default || c)
export const LazySecenekler = import('../..\\components\\default\\Secenekler.vue' /* webpackChunkName: "components_default/Secenekler" */).then(c => c.default || c)
export const LazySepet = import('../..\\components\\default\\Sepet.vue' /* webpackChunkName: "components_default/Sepet" */).then(c => c.default || c)
export const LazySiparis = import('../..\\components\\default\\Siparis.vue' /* webpackChunkName: "components_default/Siparis" */).then(c => c.default || c)
export const LazyUyeGiris = import('../..\\components\\default\\UyeGiris.vue' /* webpackChunkName: "components_default/UyeGiris" */).then(c => c.default || c)
export const LazyUyelik = import('../..\\components\\default\\Uyelik.vue' /* webpackChunkName: "components_default/Uyelik" */).then(c => c.default || c)
